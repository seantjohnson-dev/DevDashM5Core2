#pragma once

class SensorDashboard {
public:
    bool begin();
    void loop();
    void destroy();
};