#include "SensorDashboard.h"

bool SensorDashboard::begin() {
    return true;
}

void SensorDashboard::loop() {
}

void SensorDashboard::destroy() {}