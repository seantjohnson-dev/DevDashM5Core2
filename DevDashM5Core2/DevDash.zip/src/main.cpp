#include <Arduino.h>
#include <M5Core2.h>
#include "DevDash.h"
#include <FS.h>          // For SPIFFS (on ESP32/ESP8266)
#include <SPIFFS.h>      // Only needed on ESP32
#include <ArduinoJson.h>

void setup() {
    Serial.begin(115200);
    M5.begin();
    
    GestureTrigger::Config cfg{
        GestureTrigger::Type::LongPress,
        GestureTrigger::Button::B,
        1500
    };
    DevDash::begin("M5Core2", cfg);
}

void debug() {
    M5.Lcd.setTextSize(2);
    if (!SPIFFS.begin(true)) {
        Serial.println("Failed to mount SPIFFS");
        return;
    }

    // Open the file
    File file = SPIFFS.open("/wifi.json", "r");
    if (!file) {
        Serial.println("Failed to open /wifi.json");
        return;
    }

    // Allocate a JSON document (capacity depends on file size)
    StaticJsonDocument<512> doc;

    // Parse JSON
    DeserializationError error = deserializeJson(doc, file);
    if (error) {
        Serial.print("Failed to parse JSON: ");
        Serial.println(error.c_str());
        return;
    }

    file.close();

    // Access the "networks" array
    JsonArray networks = doc["networks"].as<JsonArray>();

    // Loop through the array
    M5.Lcd.setCursor(0, 0);
    for (JsonObject network : networks) {
        const char* ssid = network["ssid"];
        const char* password = network["password"];

        Serial.print("SSID: ");
        Serial.println(ssid);
        Serial.print("Password: ");
        Serial.println(password);
        Serial.println("------------------");
        M5.Lcd.print("SSID: ");
        M5.Lcd.println(ssid);
        M5.Lcd.print("Password: ");
        M5.Lcd.println(password);
        M5.Lcd.println("------------------");
    }
}

void loop() {
    M5.update();
    DevDash::loop();
}
